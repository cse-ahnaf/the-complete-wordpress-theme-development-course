<?php

/** Template Name: Trailers 

*/

?>

<?php get_header();?>

<div class="blog-wrapper col-2-items">
	
	<?php	
		$args = array(
			'post_type' => 'trailer'
			);
			$the_query = new WP_Query($args);
	?>
	
	<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post(); ?>
		<div class="single-post col-2-item">
			<h1 class="post-tite"><?php the_title(); ?></h1>
			<?php the_content(); ?>
			<h4>Directed By:<?php the_field('director'); ?></h4>
			<h3>Starring:<?php the_field('starring'); ?></h3>
		</div>
	<?php endwhile;?>

	<?php endif; ?>
	
</div>

<?php get_footer();?>
