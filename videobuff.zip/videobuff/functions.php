<?php
/**
 * videobuff functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package videobuff
 */

if ( ! function_exists( 'videobuff_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function videobuff_setup() {
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on videobuff, use a find and replace
	 * to change 'videobuff' to the name of your theme in all the template files.
	 */
	load_theme_textdomain( 'videobuff', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => esc_html__( 'Primary', 'videobuff' ),
	) );
	
	register_nav_menus( array(
		'header' => esc_html__( 'Header', 'videobuff' ),
	) );
	
	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form',
		'comment-form',
		'comment-list',
		'gallery',
		'caption',
	) );

	// Set up the WordPress core custom background feature.
	add_theme_support( 'custom-background', apply_filters( 'videobuff_custom_background_args', array(
		'default-color' => 'ffffff',
		'default-image' => '',
	) ) );
}
endif;
add_action( 'after_setup_theme', 'videobuff_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function videobuff_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'videobuff_content_width', 640 );
}
add_action( 'after_setup_theme', 'videobuff_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function videobuff_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Blog', 'videobuff' ),
		'id'            => 'blog-sidebar',
		'description'   => esc_html__( 'Sidebar for the blog page.', 'videobuff' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	
		register_sidebar( array(
		'name'          => esc_html__( 'Header', 'videobuff' ),
		'id'            => 'header-sidebar',
		'description'   => esc_html__( 'Sidebar for the header.', 'videobuff' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	
	
		register_sidebar( array(
		'name'          => esc_html__( 'Movie Reviews', 'videobuff' ),
		'id'            => 'movie-review-sidebar',
		'description'   => esc_html__( 'Sidebar for movie reviews', 'videobuff' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3class="widget-title">',
		'after_title'   => '</h3>',
	) );
	
		register_sidebar( array(
		'name'          => esc_html__( 'Actors', 'videobuff' ),
		'id'            => 'actor-sidebar',
		'description'   => esc_html__( 'Sidebar for Actors', 'videobuff' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	
		register_sidebar( array(
		'name'          => esc_html__( 'Home', 'videobuff' ),
		'id'            => 'home-sidebar',
		'description'   => esc_html__( 'Sidebar for the front page.', 'videobuff' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );
	
		register_sidebar( array(
		'name'          => esc_html__( 'Footer', 'videobuff' ),
		'id'            => 'footer-sidebar',
		'description'   => esc_html__( 'Sidebar for the footer.', 'videobuff' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	) );


}
add_action( 'widgets_init', 'videobuff_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function videobuff_scripts() {
	wp_enqueue_style( 'videobuff-style', get_stylesheet_uri() );
	
	wp_enqueue_style( 'header', get_template_directory_uri().'/css/header.css');
	
	wp_enqueue_style( 'styles', get_template_directory_uri().'/css/styles.css');
	
	wp_enqueue_style( 'footer', get_template_directory_uri().'/css/footer.css');

	wp_enqueue_script( 'videobuff-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );

	wp_enqueue_script( 'videobuff-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'videobuff_scripts' );

/* Custom Image Sizes */

add_image_size('blog-thumbnail', 600, 300, true ); 
add_image_size('post-thumbnail', 1200, 600, true ); 
add_image_size('homepage-thumbnail', 400, 200, true ); 
add_image_size('homepage-review', 800, 400, array('center', 'top')); 


/* Customize Read More Link */

function wpdocs_excerpt_more( $more ) {
    return sprintf( '<a class="read-more" href="%1$s">%2$s</a>',
        get_permalink( get_the_ID() ),
        __( 'Read More', 'textdomain' )
    );
}
add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );

/* Customize Excerpt Length */

function wpdocs_custom_excerpt_length( $length ) {
    return 35;
}
add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 999 );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**                                                     
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

/* Custom Functions */

function displayName() {
	echo 'Welcome to this website'; 
}
function displayCurrentTime() {
		 $time = current_time('H:i:s:a'); 
		echo 'The current time is '.$time;		
}

function reviewExcerpt() {
	$link = get_permalink();
	echo wp_trim_words( get_the_content(), 100,'<a class="read-more" href='.$link.'>'.'Read More'.'</a>');
}


add_action('wp_footer', 'addGoogleAnalytics');
function addGoogleAnalytics() { ?>
	<script>
	  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

	  ga('create', 'UA-37999354-2', 'auto');
	  ga('send', 'pageview');
	</script>
	
<?php } ?>

<?php

add_filter('avatar_defaults', 'customGravatar');
function customGravatar($avatar_defaults) {
	$myavatar = get_bloginfo('template_directory').'/images/bond.jpg';
	$avatar_defaults[$myavatar] = "Bond";
return $avatar_defaults;	
}


function newContactFields($contactfields) {
	// Add Twitter
	$contactfields['twitter'] = 'Twitter';
	// Add FaceBook
	$contactfields['facebook'] = 'FaceBook';
return $contactfields;
}
add_filter('user_contactmethods', 'newContactFields');

function removeVersion() {
	return '';
}
add_filter('the_generator', 'removeVersion');