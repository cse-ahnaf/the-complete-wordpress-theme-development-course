<?php get_header(); ?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div >
			<div class="row-1 trailers">
				<?php	
					$args = array(
						'post_type' => 'trailer',
						'posts_per_page' => 1
					);
					$the_query = new WP_Query($args);
				?>
				
				<h2 class="row-title">Latest Trailer</h2>
				<hr>
			
				<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post(); ?>
					<div class="single-post">
						<h1 class="post-tite"><?php the_title(); ?></h1>
						<?php the_content(); ?>
						<h4>Directed By:<?php the_field('director'); ?></h4>
					</div>
				<?php endwhile;?>
				<?php endif; ?>
			</div>
			
			<?php wp_reset_postdata(); ?>
			
			<div class="row-2 posts">
				<?php	
					$args = array(
						'post_type' => 'post',
						'posts_per_page' => 2
					);
					$the_query = new WP_Query($args);
				?>
				
				<h2 class="row-title">From the Blog</h2>
				<hr>
			
				<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post(); ?>
					<div class="single-post col-2-item">
						<h1 class="post-tite"><?php the_title(); ?></h1>
						<div class="featured-image">
							<?php the_post_thumbnail('homepage-thumbnail'); ?>
							<?php the_excerpt(); ?>
						</div>
					</div>
				<?php endwhile;?>
				<?php endif; ?>
			</div>
			
			<?php wp_reset_postdata(); ?>
		
			<div class="row-3 review">
				<?php	
					$args = array(
						'post_type' => 'movie_review',
						'posts_per_page' => 1
					);
					$the_query = new WP_Query($args);
				?>
				
				<h2 class="row-title">Review</h2>
				<hr>
			
				<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post(); ?>
					<div class="single-post">
						<h1 class="post-tite"><?php the_title(); ?></h1>
						<div class="featured-image">
							<?php the_post_thumbnail('homepage-review'); ?>
						</div>
						<?php reviewExcerpt(); ?>
					</div>
				<?php endwhile;?>
				<?php endif; ?>
			</div>
		</main><!-- #main -->
	</div><!-- #primary -->
	
	<div class="sidebar" id="home-page-sidebar">
		<?php dynamic_sidebar('home'); ?>
	</div>

<?php

get_footer();