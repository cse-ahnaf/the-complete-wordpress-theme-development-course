<?php
/**
* Template for displaying single movie reviews.

*/

?>

<?php get_header(); ?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php
		while ( have_posts() ) : the_post(); ?>
			<h2><?php the_title(); ?></h2>
			<h3>Directed By - <?php the_field('director'); ?></h3>
			<?php 
				$date_of_release = get_field('date_of_release', false, false);
				$date_of_release = new DateTime($date_of_release);

			?>
			<h3>Release Date: <?php echo $date_of_release->format('j M Y'); ?></h3>
			<?php the_post_thumbnail(); ?>
			<h3>Starring</h3>
				<em><?php the_field('stars'); ?></em>
			<br />
			<h3>The Review</h3>
				<?php the_content(); ?>
			

		<?php endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->

	<div class="sidebar">
		<?php dynamic_sidebar('movie-review-sidebar'); ?> 
	</div>
<?php get_footer();?>