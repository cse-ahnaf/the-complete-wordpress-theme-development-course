<?php
/**
* Template for displaying single actors.

*/

?>

<?php get_header(); ?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php
		while ( have_posts() ) : the_post(); ?>
			<h2><?php the_title(); ?></h2>
			<h3>Nationality - <?php the_field('nationality'); ?></h3>
			<h4>Height:<?php the_field('height'); ?>cm</h4>
			<?php the_post_thumbnail(); ?>
			<?php the_content(); ?>

		<?php endwhile; // End of the loop.
		?>

		</main><!-- #main -->
	</div><!-- #primary -->

	<div class="sidebar">
		<?php dynamic_sidebar('actor-sidebar'); ?>
	</div>
	
<?php 
get_footer();