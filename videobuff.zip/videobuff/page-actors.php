<?php

/** Template Name: Actors 

*/

?>

<?php get_header();?>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<div class="blog-wrapper col-2-items">
				<?php	
					$args = array(
						'post_type' => 'actor'
						);
					
						$the_query = new WP_Query($args);
				?>
				<?php if ($the_query->have_posts() ): while ($the_query->have_posts() ) :$the_query->the_post(); ?>
					<div class="single-post col-2-item">
						<h1 class="post-tite"><a href="<?php the_permalink(); ?> "><?php the_title(); ?></a></h1>
						<div class="featured-image">
							<?php the_post_thumbnail('blog-thumbnail'); ?>
							<span class="image-overlay"></span>
						</div>
						<div class="actor-meta">
							<?php 
								$dob = get_field('dob', false, false);
								$dob = new DateTime($dob);
							?>
							<h4>Date of Birth: <?php echo $dob->format('j M Y'); ?></h4>
							<?php the_excerpt(); ?>
						</div>
					</div>
				<?php endwhile;?>
				<?php endif; ?>
			</div>
		</main>
	</div>
	<div class="sidebar">
		<?php dynamic_sidebar('actor-sidebar'); ?>
	</div>
<?php get_footer();?>
